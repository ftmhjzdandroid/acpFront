export namespace ACCESS {
  /**
   * 'پنل نسخه الکترونیک نوین'
   */
  export const HAXPanel = "HAX";

  /**
   * 'تب اعلانات '
   */
  export const Notifications = "HAX_NOTIFICATIONS";

  /**
   * 'تب سوالات متداول'
   */
  export const FoldreFaqs = "HAX_FOLDERS_FAQS";

  export const None = "none";
}
