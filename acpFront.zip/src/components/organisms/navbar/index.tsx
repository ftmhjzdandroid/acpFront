import React, { useState } from "react";
import { Box, Logo, Typography } from "../../atoms";
import TabBar from "../../molecules/tabbar";
import { IuserRelatedModel } from "../../../models/user-related/user";
import UserProfile from "../../molecules/user-profile";
import { useCustomNav } from "../../../hook/useNavigate";
import HamburgerMenu from "./hamburger-menu";
import BergerMenu from "../burger-menu";
import { Avatar } from "../../molecules";
import PopoverMenu from "../../molecules/popover-menu";
import { PopoverListModel } from "../../molecules/popover-menu/model";
import { LogoutCurve, Setting2 } from "iconsax-react";
import Setting from "../../molecules/setting";

interface IProps {
  children?: React.ReactNode;
  appName?: string;

  userData?: IuserRelatedModel;
  ssoUrl?: string;
}

const tabBarData = [
  { key: "1", route: "notice", title: "اعلانات" },
  { key: "2", route: "education", title: "آموزش" },
  { key: "3", route: "conversation", title: "گفتگو" },
  { key: "4", route: "cummon-questions", title: "سوالات متداول" },
];
export const Navbar = (props: IProps) => {
  const navigate = useCustomNav();
  const [isProfilePopover, setIsProfilePopover] = useState<boolean>(false);

  const [showSetting, setShowSetting] = useState(false);

  const handleShowSetting = () => {
    setShowSetting(prev => !prev);
  }


  const logOut = () => {
    window.localStorage.removeItem("S3OJWT");
    window.location.href = `${props.ssoUrl}?from=HAX` ?? "";
  };
  const storedTheme =
    localStorage.getItem("acpTheme") ||
    (window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "purple");
  if (storedTheme)
    document.documentElement.setAttribute("data-theme", storedTheme);
  const popoverProfileData: PopoverListModel[] = [
    {
      title: "تنظیمات",
      icon: <Setting2 className=" w-6 h-6" color="gray" />,
      titleColor: "text-orange-500",
      child: (
        <>
          {showSetting && (
            <div
              onClick={e => {
                e.stopPropagation();
              }}
              className="absolute -right-64 h-16 w-64 top-0 bg-white z-50 rounded-lg"
            >
              <Setting showHeader={false} className="h-16" onRenderPage={() => { }} onMode={() => { }} storedTheme={storedTheme} />
            </div>
          )}
        </>
      ),
      onClick: handleShowSetting,
    },
    {
      title: "خروج",
      icon: <LogoutCurve variant="Bulk" className="text-orange-500 w-6 h-6" />,
      titleColor: "text-orange-500",
      child: <></>,
      onClick: () => {
        logOut();
        setIsProfilePopover(false);
      },
    },
  ];

  return (
    <Box className="flex justify-between items-center px-2 lg:pr-8 lg:pl-10 py-5 mb-2 h-20 th-primary-bg-color border-b-2">
      <Box className="flex items-center justify-center lg:hidden">
        <HamburgerMenu appName={props.appName ?? ""}>
          <BergerMenu />
        </HamburgerMenu>
      </Box>
      <Box className="hidden lg:flex justify-end lg:justify-start gap-2">
        <Box className="flex gap-2 items-center">
          <Logo
            className="cursor-pointer h-14 w-14"
            // src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAASGSURBVHgBtZhBcts2FIZ/QEp3TdRdZxpH7AminqDUCSw27bryCWyfQPQJPD6B1XWbsj6BkRNUPUHZuIsu1ckuI5P5n0AmIETalMj8M7YIEHj8ADw8PFK9CJO/0UE5kL4DorWJ1m79KExGXwKJAgKvS4A9NNy3gy8BeArcIkymLiThrnkvREdp9KOJQMqsSeEoTARuhh6kuMS5U14Xf20VuAUaMhlwPgD+9NqtVEu7ubUZlOWhd3N1Z6IpWoqDi/mzKMuypFySU9o54fW1rc0u3ppXcXubvy9pKSjLnZb4rYli/ly4dQSb8+d7gdwXrk6dffAhyK5wos6AL8IbWWLx4x1I2SzoqOFjDb4Ok+AJsrDunoJ+yWU8K4oxLKTrk3P6aZph86au/wbD9D8TpegCKHAEaTMTMUGm2ppcuPW64TFf0EdhB3Y4YFvlyH/51/xkeGk4a1K1QA/qJVAL3J35YV6W6zbOoTpgBvMrAq3cmgH0H34rgeQmYbtsVNYpqJD/f8bnBBS4O/Nq+VAbOfLkXGbQr4Afha8Fci/Avs5iB+K32dPdo65Wkgk91qYCKEcV45o3Qgkl7aUwWGTIb9q1rtr+JkwmtHBcacG/VbVTtiwhJQgT+swzunPos90pd+41l3BOuDca6pkE6TK7aR4Mzthvu9ufh7+GA0nb6CFOk1QFNJLZGxMHkjtwyBXIYtegv1tFAtUUJyW78ZOPIyYDrh+KTc76rUyM133F2Yt0SmfmxZSjMSVcDj1uAyfS0I1OryqDthIbYqsF3JRsqUJldIkkmcfFYe+oPiuRJSw2RIAGvQe+rTvO+CyZ+Z2JcOC2ruTv4lq4DJnxH0DXkFT/Mt/x4YrSJ7ifyM72bzTB5bi/SJ1XB+2M6LoOTnyRZ+lt6cyuCDfi3xWaZRjGR/S5ylLbDKgODoZLnrhZkJZlYkVSD6efOYZiH1LSePrguPQpT8xiIPUv6dPpQ3DS38LZiOGmarp4NZxVO+BEfI4dv/IeGgfbWMWn06/yrbFspni6MLxcEYjZDL5j9XnOAdLugjbUoNiAz8MkbNp8bPu/N/j5mBOn1e6LzwlDw1Kui46V42qDzcc4xQef2yu9YOw7JdxlZnPHyyL0rIdQy7Qh5xPbZWSoSzDIMtFehSnhPtVlf6FB4sz/mCiC9UNxbM6uvpRrsSUDYJvGTeTbLiBTt66XfLAwLMsfFOApetIBgIMZT4/gUzln1vLj1g18MDll3DKXdIzPDSi+tn2UI3k/5ixeVOtqQ8ne6ivdqoSgvuBEvb2TwELiHrjpC070KCAD8XLzMZGoivFv7mXIMXcu3E8fNojntf35qvDQMdkOsHD8tOG2Yfrkp/Ex4WL76SMP6zKgfdTZBwdQcjz5MyGQ465wos6AGfRxbl1gB7IuwdhXnQDtq0G2tIe8XqIW8vUZOkgV36iDorx+JL+rdvY+8UqKntkvCn4mnaK9Arefv0lGHb4ry8CMtl9Z/Sw7wIHqK1CnZZpevuNgv1lr1CGBOvXKAhS5abqEJiYOU86kfEUa4UDJi/0Hd97yWc02o6IAAAAASUVORK5CYII="
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAE8CAYAAAB6q4zuAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAOdZJREFUeNrsnXmUG1ed76/Udi9uL7IdJ85qNWQZAu+k82+OD5bfPzOsbgMBAgxWZ4CQQGK3s5Ol3TPMMOedN+P2DENeMgOWSTBLCG4PeYG8ECwH4z+GxZ0BErI4UTbv3S23e9/07q90S6oqVZXqlupW3Sv9vueU1ZZKUqmq7qe+v1/97r2EoFAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAoVlmK4C1BBKX/91Un6kHRbJ/H4C1ncUygEFiosKHXSh04Gpg3AIPZ/XuUMyxt0AZANUqDlcS+jEFgov4BK0YcUg1MqhK/MMXgdhEcKsBweBRQCC+UEKHBMXXTZxACViHiTBumyhy4DCC8UAgtldFJb6JKWeDN1eGUwdERgoRrTTQGgtpIqyXIJlaFLH7ouBBaqMUC1jYEqofjPyTJwZfHIIrBQCCqVwNVDwTWIRxqBhVIfVhD67axDUNmFij2Y40JgodQEVYo+7Cbq5ahq+tksTOzHMwCBhVIDVJ3MUaUaeDcMMreVxTMCgYWSE1TgpHqJ3OUJGCaiEFgNDqqwE+p55mAOGv7WXI0TGJjrS5Byd55rWKjaGdL2YpiIwEJJAKs0EZ9QhwY/QAR0mWGwBWjp1fUiAYZhIgILFRGooHGLTKjnWTi1J8xyARbWQvegLQLhhWEiAgsVIqh6ibiEOriPXbQxD0jwW5MszE0LcJAYJiKwUIIbr8iEeoaBalDC3y4yR4dhIgILJaCx9gr6igHWYHMK7QsR4MIwEYGFqrGB6qASkVDPEkX74TFw7RTgNjFMRGChfDTILtYgkwI+PscaZaYO9lOK7aegk/MYJiKwUB4boKiEOrgHyFHtQCfqWf0M7hgmIrBQhgaXJGIT6nXf8ASHiT314EgRWKggGhkm1NUIE7MEh7BBYDUwrDChjmEiCoElfUNKs4aUFPDxORJhQr37xi8ktd9VKJACe65QKAzuyXwnH9G+xjARgYWqIVQRmVAP7Xb8F754E4ApRWEEHZg76aPWsZk+6pQyAkt/1DpJA8Do8jy4wMce3ZMLcd9jmIjAQnloLEnWWLoEfUUfhCmiQ5Qv3XQzNPYtFDbwO5IAIgOMTI8OwCo9Gv4GYA3Qx117v/doLoRjgWEiAgvlEo5A49gm6CsyJISZYyioIJzaqrsTB/D4BZbxcZAAuPY+lgnhuGCYiMBCGRrFDiJubKosCSGhftOXb0kz4CZLIBILrOL7qOvq6HhX3z/8w9+JBheGiQishgdVqZEL+PgcawhCR1G4+Zavpik0eumStEIqJGCRltZWctFFF+daWlq6ex+8Lyv4mGGYiMBqOFCliOIJ9ZtvuZVue0H7DUaoRAEsUDweJ5etS5LW1lbNUYoEF4aJCKxGAVWSKJ5Qv+UrtwGgGGwroRIVsCzQ0kMtcFw5DBMRWCj+K7LSCfWvfPU2gC0N/YquoggKuYAFfwO01iU7dGiV9o1gcGGYiMCqG1CJnOwhSwQn1L9661YGqgIDlREs8gFLg1ZTE0maoaWDq4eCKy/wWGOYiMBSFlZpIjah3i0SVLfe1kMbYGEbg5UBFvIDCwSJeIBWE4WX8bC89dZbu0ZGhvuf+PGPRIELw0QEllKgEnXChnK1LYJKd4WFRCU01AAW/Lt69Wqydu2Fpt83Pz9PXnvtaH5yYmLXE088vgPDRARWo4IKnBTMSpMSBKpdRHBC/bat28EV7qSNnjUyO2ioAywQuKz29nbT75yZmSGvvPwSmZubA6fa95Of/Dgj6JzAMBGBJWWeSsRJacy9CE2ob92mgQoS6kkzcNQH1rJly8hll62r+M0jw8PkzTff0N8H+7Zn374nBgSdIxgmIrCkAJXohLrQk7Fn+x1QoqA1pGJjtwJHfWDB/9/znqutuSxNL7/0ZzI5OWn83Oy6ZMeeXf3/JMpxYZiIwIoEVmmicEK9Z/udKWPRZ7mx1yewOjreVREWgk6fPk2OvfO26XMBbO969+U5un7fjt77MwLOnQRLHQRdi4dhIgIrNGsfygm3/fa7ksxRdRlh06jAGhsbI0dffaXic6GW64orryRtbUvgogHgygo6l0TMxI1hYqMDS/WE+u133J0kploqM2zqGViLFy8mV155le1+cQIWPDY3N5P3vu9/GCHQTcGVE3Bu7RCUVmj4MDHWoKASPXuysIT6HXfereXZaPvrrWzw9Q+sJvsCUk/AAkE3HyiNKDWAWEw7XkFXzQvsspVn6YUBBFZ9gyqMhHq3KFDdede9MJon3f6Ctv1WEDUCsFYkEmTNmvM1p+Skt958gwwPDzt+/ooVKyCfZQSWyREHXTUvOEzsbqTJRRoGWCyhvlMQqIRPuElhpVenl2qpGgVYzS0tZOnSpSSRWKmFggbIVAjuDsJdQqfvBMFnXWEJJw2fp+UcKbQyAs5BUWFiKKPNIrDCAZWoqxsoRwRP9nD3PfeZxqUyQqcegQWJ8ZbmFtK2pI2CqpUsWbKENNHn7CBl/T/A6rWjr0LhqCuwLr7kEnL++Re4fhYcW/p5ff/4ja9nAj4fRYWJORLCOGkILLF5KmUT6vfce1+Kti8NtHaNux6ABZCA0A5yUc0UUi3USekOihgAEnOAivH/J0+epMsJkztzSrpf9RfvIYsWLaoGLGPYFfg4XBgmIrCs1lvUpKQZdiUTBKr7U+VaKuIIBRWBBUACMAE0mpsXM2jETMAogcMGWFawLCwskNHRUQ1WMzPTFeGkXVnD5VdAWUObLaBcoAXfk/3TH//Q9/OfP5UVcK5imNiIwKIHv5NdtUTUUwm9ct37tQc0R0gbV8oOSKoBq5k6pUWLi1BavLhZc05WKJX5EDPBwgot4wkKkDp37hwZHx+nEDmrdXp2yn8ZHwFSl162Tnt0gpMbsIrQOkteefnlzPT0dN/TT/8sF+B5i2FiowGLdY/YKeCjhSbUv3bfg1qfRXMtlVrAAufS1LSIwqmJLotLcLIDUvH5SmA5uazZ2VkyOTFBJibGydTUlLa45aeswIISiNXnrSEXrF3r6NS8AgsEoKROC/JkmtOm4MoHeA5jmFjvwBLYJQIOrtCE+n3393bRRgXbnqgGJFmABY06Hm/SIAXuCYAQj8eqQMnu+ZgtsKh70UZdAEhNTk5owHKqdHcDlgaq1eeR1WvWlPobxqoAyguwjNCi25an39X3zDNP9wd8TosIE0OdZBeBFV4IKDyhfv8DvYli+FeErBcgRQWsIljiGpSKcIrbwKkSSl6ABZqeLrqm6ekZDVAQ8nntmmP3uGzpMrJs+TKycuUq11xYLS4LdPzYMRh/S9+2LF26n332GRXCROXdVkxRWIF93hfwVUh4t4f7H9gB/f2Yq/IOpLCApb8GYCo23lgJSkbglJ+vDP2cXNTCwrwGptnZGc1JwVItrPMCLCh9WEpBtZyCCvJlFeDxkMDnBRbot7/5Lw22bPvoOVPY/Oyzv8gKOM+DDhOVrpSPKQirNDuIQWmA5amEXXUeeLAvwToop8vAiBZY4GbKn22GTBk8ZmCVG7W9kzI2eKiHAjhBiAehnf59Tr/JK7AApu3tSymo2rRxsSBEtQLHC7BqCQtBMO7Wm2+8Udq+4rLQfeDALzMCznkRYSJEET0ILHVglSUhzJ78YO/fdrJcVacZKuECC+6oFaGxUAy9KkK4mC2w3ECmC9wTQAm+A0Cl3b0LqNIdvgdqtdralpDWtrZSH0JrDiwIYPFAa2hoiLz4wp+swIKXREFLRJg4wNxWHoElL6xyRHBC3QCrrmK+qjyOeljA0uBBITLHQGWfY4pxuCli+uz5+QUNVNbSglq75ixqatLuNMKEE62tbVr9lh2MzFypBJVdTVeQYeHZs2fJH/77+Qpgwc+g+7v7ueeyGUHtIOgwEe6Eb1QFWrEGgxWAakcY2/zgjr9Lk6KzcoBKsMAChwMhGDzq3VM00MAjy0nZAcsILjtoLSyUG6MOviC75kAhKQBKLyqFu49OJRGVTsoDsATlsU6dPElefvklJ2DBKpsptAYEtokgw0SA1mYVkvGxBoFVqAekl8KqANts25iDARZASSsDYAnsgsUxlRbWYO1es3NZ5e8PvmsO3GkEIBWXxRqg7AFqD6Jq64WZx4IJL6DK3gVYefq48dCh5wYFto0gw8Q8c1qDCCz/BwRKFg7UeBUJzVUxWME2HykYqBQUsKAGaGpqUgMUhHsm2Bj+jhsdlQOwYB3j3UC7sLIWYMVjrBSiaZHmoABS8VJHZnsY+QeW97AwiDwWXCzgLiE8ugALHgcpsK4NoZ0EFSYCtK6V2WnFJYZVokZY6VeMHSFv+r6gPgjCO+gScuL4MZJ7/TWtgy/0n4M7bwULRIwyNSIGD72bDOSEIHENECkDq8arHvt8COtg2OLly5eTZXRpX7pU6w5TDPOs31Ow3W4jzKvJ63rGFQsBHJfj9Hjoubsq6ly//v3Czz+4cUSXDlLsQ1jTR8H5y9oeOixOYB0h/otCI0kk7uj7+g4YDqbUMHw4rFkKo9FzoyQ/ktc69VaEchb3ZPdaE0tcwwLdZgBMQXbNqXRpcZPrsSbtK52Uc45K9rAQXO7zg0cszsrRYelv66BOKxdSuwmioFraRHxcUljVMinEQIQ7e6ufN4FjOn3qlJYX+fOfX6RX8ONa6GeFhh1I9NwQ3PZftmw5WbVqFVm5cqU2UB3kiPQwrFYHBfVOxT6Di0t5KKNDc4JbNU9TGQ5HL6dt0bvl+MkUhLXtLAe1kRRHFvErHXrosDzAqquGsCpDD1h3FNtN3ZW23aaqbBeHNTs7R06fPkWGzpzRKqbjNnfy7PJOhDkoCLVaWqA+qVUDSa2V7mWHYO2aY1fhTiryTtVes89TObsnkXks64nvJY8FF5Rc7nUtTK8Iu6s7LPi74/DhQ7mQ21K6RvD0RZBScdUiCfNWu1WDFdMmT7+RhnrHTxzXGgCMcFB0Lk0lUJQcCyOJ/n8YrmVp+1LSvrRdy0FVgohPxVqqeRO4zJAxOw7j87C6U9RkfM36Ppu1Ha+Z5c+xX0f/bLdtcdwwDkHO8O233iJnz9Zs2MFlhXp+Qq0hbVM54r8bWy99/6BM3XhikgELdmyXgrACh6Xl3JwcVrHD7GtaqKe7paam4tAsesdiaz6qjYIJxjKH5DXko/xWusOVXu8eMz8/Rwr6ld+l1KHS8dhXvtvlqtwcmJuDkimPdebMaXLm9GmtQNQudPXhsIB44LLyEbSrWu62S3XncJFEsOryCavBqGHFTvhOO7cDvfqhz5lezGk+2c0nvtYNhYZ6kIeCO21wV88uZ+XFPRULSWdLQ7RUQMkhb2N2UlaHZHY71R0Un+Gp5fOcHBvPZ05MTJCTJ06QkZFh0/EKyvCw8zsT9rkJeS3avjb6hJYe9WxEYJlDQT8D8A3KsCP7/vbvU9bnIOSDGVxgcgT7BlsouSJIjq+kkILJEYpTWBUID6Ogcc1oY0kVx5PSruw2zskOSn5BUQmcMiycwkL773GGjNcozk9YqH8rjGCaz+fpMqLtQ8HJ/01RACsAaKVgkEwZxtOSxWHBiKFJH1ZVuo6bAA+4k3SKAquali9fQS659JLS+E1eGwsAaXJyShtDCopIwVFZSxyquSc3WHl9zi/weD9fx0sZZOZHnm0CoI9RSAGozlJIzen1VOHcpUxFeW7WCC3IZw1EHRpGDizWvcBPOUCPRN0ItBMRGsHgkd87uipdF154IUl2vIslz72FfFDZDrMa68MF2zko4iHMMyHAxpp4gYlXUJjXK3hKmdYeFlaGx1COMD52ju2/Ca6LQ9DMuO669Z2HDx8ajBhamxm0lAsNZXBYvT5oPxDGaAs8Akj95r+gu8asC6guIh3v6jDd5XMTgOksDVfGaGMD51YNUKZGXyQVFxS8OR+3PFZ1KJmB5na30R+4oAM47LfxsXENVOBCIwSUnTpZKiNKp5Wl0Oom/HfkITRMiR6SSVpgMXeV5nwbWNJuIpn++If/doQVTK9+xZVXsrGc3BvOFAXfCA1VRkcppGjj8wwpQ1jD67gKVd7n7LSiL28AxwRDLU+MF50nhHySAcqqpAwbwUoeNvhofwC5jkZ1WH4qgHtky1sdffVVMjw8XPE8FHde/d73kUQi4dqIIGwZHhoiwyPDZJo2ulJnZg/hky43ILgCySEstK5fLSx0CgWdHBh/HotoJSFQcAuPU1PTGqhM+0FeSBm1QqJt6WHpDB6IJqEgNaoIJzJgsTuDvHQfkHEs6rfffqviJLzooovJlVddpXVhcQIVFCUOnTmtwa5awtwqt5DPCKOCm+Mi9uUNtYWFfHIqbyje8Zwls/RxmrqmGTaEjuTuyWtIKIXgws/yWUd8GI3GAhYp3hn0c0WQTjQUMZ2EV131F+TSdescr/gnT5zUevxD3guKRm27hkDD9OCy/LiuWsobqoeFfOUNEEbrdWMz0zNars4YWvupQ0NxQQuS8P2c7TEylxUlsLZwrp9RYUTE977vfZq7smti0Kn5jdzrWp4FqtyhW04Qd8VKDboK4IIob+CBmTXshXKMubnyuO8AJruB/1ChC4al6eIMDSNxWZGM1sCq2pM+dqrUevfll2uwsmpkZIT8+teHtEkLwFXZdevgBVShWCbv6b1u31FwgETBw3Mu3z1IX+unYV3/uXPnBuH3Q/gLZR9w1w7CPbe7qajwQ0Mf0UuSda5uCIe1iXN96d0VdKd597svNzViuGv10kt/1qre7XI3xjuGdo1fDwutQPHqekIsb8jBhKL09f307+y//stO002RLekbIV+ZossGul5KpjwOqgStAQqgLOErbt0StssKHVg+k+1KuCujAFJQ8W7tk2bfaTa4YsmQyhtydB04uQ8CoP7tm//iejHZk/kOAGyALeSvP58uAYw9IsDkCQ15gAV1WckwzUQUDou3g/OACu5q1arVpQYPrgo6PFfLJVldlj9CFUyfIKi8AYCjAQqc1MP/51s1FT4++t2MCWCf/dznEwxaRoihwndZWR8uaysJ8WZYFMDawLn+HtkP9DWd5XkG/vTHP5Jjx97xFK5ZR2zwApuKsNFj72De8gYdUACVRx5+SGhl9vce+64OxKz+3A03fDaFAItEuzj3d1e9A4vHYeVlrLuyqrm5WXOAR4++ygUr63RabnmsEMobBhkw9n/7Px7JRr1Pv//975kA9qlP3YAAC8dlDbBB/5Ie3wLJ986w+vWGCiw2kBhPv8EBRY7zG1D8CRXvnNEcMQ66F3J5w6AxD7V797elnvn3hz/8vglg13/y0wgwsS6LZ7inLSSk/pFhOyzeE2u/Kkf46KuvcMOl1uR7ySHpYZ37e7U7eQAoANWj383kVG5Rj//oByaAffwTn0SABacMJ7BC299hA4snf6VEOAgCd2XXl5DXZVULCznLG7S8EP08LQ/1/b2P5eq5hT3x4x+ZALZ588d1gF3DHhME5TUshC470Pa8pm86w7pbGDaweG5fZ1U5wCM+YCWovGFAD/FoCDXYyI1u374nTADbtGmz9S4kAqx6dMOTb06REGqyQgMWq79KcrzlYL2fEcY7hT7LG7I6oJjDiERbt21PsYvROoeLEri950lxaKDsrv5/Dt3t7d+/b5DlWbRhfj/ykU0IsOoXP57xsjbUFbAIf3FgwzgEr+UNBdgnLA8FDX9g4CeRJcoppNKk2GPB61W4y/DeHGsQeyi8IjnOP/3pfhPAPvzhjyLAKsPCQY52G0rxr7TAinJUw7Adlkt5g15geZAibODJJ/8z0jt5FDTQiKFX/9YaG3SSfc42+plwnPsouCI93nTfmgD2wQ9+OMWAnG5geO1vZGDxHHSl3NWrr74Cjc33dOQ25Q3weXt+9rP/m5HlNzJHtVNA4wUwpBi4uqMIF+301FNPZlnI3fOBD3wIfvsW0nh3H7naYRjDJ4c5WgPXHcLGCgdLS4YuHU8//bONP//5U1LAClwVXfaxfIZIpwEwOMLAKJXgwkGPB0y+sJEodDMoAPH+1qToDYpLuqMOksZSdmGh0PHLX/6i+xe/+H85WTaKwkOfMbgrpK/UZmah37tTxoNEoZWFiwk4QXphqfuLKht2hud8rCtgJQmqwknSE3/zr351cONzz2VzMm0YhUaSwSqKkRQgt7Vb1oNGoQXuFyZiyDTAOcpzXl7TqMBqhDuEYLc7Dh8+JF1xLEuu7yPRJpvTdDu2yXrwnnnm6TxdwGl113kKg6ctCj9fZA0J691u91FQbaSLrL9zN5FjjKqdrMZLWj377DPgsmiYWMjV6bl6FoHV2OqmoNoh68ZRQEC+qkuiTdot+wGl0IIhoa+t08iA5zcJv8ghsMKHVUbybZQt4Z2U8c6hVQcO/DLPnFa9QUuqKACBhbAyuisAQ1LCTetV4QADtBYWCnAXMYenOwJL5auQCs4KtEnS7UqyUFV6PfdcFs6FzaSBagkRWIqJwsgtDMgoAiuQzFDYoMr5QKEF50M3tozgFUrXHDZSQyNqkMJKiRPXz924+fk5Mj4+Qc6NjmqzA42PjxPTlBiGP1taWkhLaytpb2/XFvg/p5SaWYdCa2D9+vfzzqiMkgFYpHE7Pqt0lfV0UYGZm4fOnCZnzpwhExPjNnOw2g9GODZ2zrQuAAtmG7pg7YWktbUl8HNIEvmZURklAbAaUX1VQkXZZAsEHTLT09PkxPFjZGhoqJxPiDdVgKny/QVbmM3OzpKTJ09qy7Lly8lll15G2pYsKQ2tYzPCjnIu/dCh5/LUZQG0dmNzCEaYwxIUBRM2TImKAsYsLBS0pVBYICdOHCevvPwSgSnn4/F4DUtTaWlqaio9Pz42Rl588QXy9ltvat8HS/G7CSkU1D4RKLQybCx9FDosqd2VUneJdDDo43OB5ufnyVtvvknGx8eKJ8uiJstQOE6hoJvLcn4Nwsyx8XFy+eWXa0DTZ0ssFGKBzYwdYWiYwmaBDktWd5VRz1UtGNzNgpZEh9mrJycnK5xRU9Miw9+wxEt/Vz4f10AHi/5/o+vSn9OXGRp6vnb0qPb9sB3FYXeK26Wqfv3rX4HDymHTQIclozKquSvd6ZRHPCXk7bff1vJMAB7vOarqjsr8ur0rg+899s475OJLLtVyWcUJgwqqnxe8c/2hEFihnZjKqZgzKkIhPzJMZmdmDAnwmCN03EI1XtAZn5+YmKDbMUISKxP1EBISwj/XHwpDQuGCuislrb+eu5qdnSH5fF4DhNtiDOu8rGNd3+m1cmgZJyMUnJBHUz0kBDHXncUmgsCSSftV3XA9dzU8NOQJRnZg8rIuD+xAZ8+e1WAK24bnBwqBFayUvYLqifYZFgr6gREv6Lx8/ti5c6b8muoOXMFtlqr+DYEVnPLU9itt+cfGxkgpy21ZYgAVfQnRdQGoIJ9VD8BS9PyQarZ2TLoHp4zKGw8OCxLtcQYJVxkS4NUwYkqWe4SO/h59O6ampkhra2u9nCeD2FQQWDLorMobD+EgJLh1Z2OUG8BiHtfjBZ0RXADSOslhKX+eNAqwGmG0BqWvnNPUxTiVDhifd4WXINABrOoIWOiwFACWVHGwICk9YBt0btbvzHmFUjXQeAWYW51XyQHOztZLm8OB/TAkRNUqIzT8OipRsIN152i4WifK4dmGwMITsVZgUXdlBxHbMDEAKHGFj15uBCgiVQuLEVh1JtVPRGuy3RUQfkO9GkBXRzksFAILFWRI6McBRQU6FAIL1YCKV4GObb4qgFDPD+hQCCwUOixu6FgxEiTorJ8XQ2ihEFioEhBYSQPxAB2voVwtoKv4PAQWCoGFqoCDh1IFR7dTZb1aQYdCIbBQmtyKRj0Dpcp6fkGHEItUKxBYKGkdVqwGh1Xw6bAIOiyZxdNL5SACC6WMw4r5dFhe1sM6LBQCC1UGwvy8NjSxI1QEOiwv6+FdQlSYwFqBu1puTc/MkPb2dmdgVNLJE1SCAB2GiaiwgcUTB+PwGxFInwfQ1WUZoeEVPvYrcYEOHRZK5pAQBziLQhQiMMTM0qVLawrxPLkjL4n9ag4PhcBCNTKvCtogfkuWLGHTxPuvPvcT4lX9LHRYKAQWygqHc6OjZOWqVdyQ4oIP8Z6nciu3QCGwUA0MqwILC2GWGj0Bz+Ok/LooL9+DwEIhsFC2OpvPk5aWFrJ4cbMVHVyhnl/Q2X0O4gqFwEI56tSpU+SCCy6wQMtfqGeFnZ+QER0WCoGFqoCFHhrCcvLECbL2wgtJc3OzTydFXGHnLWQssNdwzl8UAgvlAhCoyzp+7BhZfd55ZNmy5VVdUiWA/LkxW9Chw0IhsFDVBNA6dfKkloxfs+Z8V9gFFw5Wvh5HXkUlqeYURWChPCk/MqLdPTz//PO1O4jeaq2cw0ErqNzCQQwJI5VUc4oisFCeBYWlb77xBlmxYoWW29ILTJ0hVD309Aw6DAlRCCyUL7eVz5PR0VGyavVqGiauoeBaxHWn0O2OXzG0xJAQFS2wErir5ZcOEi/DwMzPz2u5rTOnT5PzKLRWU3g1N7dUcVT+7xSWxpxHIbAki4NxtIaIYGXKJ0Fpg6Vg085FAbhOHD9Ojh97R7ubuHq1fkfR3VGVuwhWz28B6LB0FCVrSJjHwyK/CyuFatT5wJ3EWKyJDA8NkaEzZ0hzSwtZmVhJAbZG60ztNexzCx1jGBOiCOawUG6hmIvLMq4P0Co+H9dANDc7S06fPqUtECYmVq4k51F4tbW1uboqt9ARHRYKgYWqHWqGcNIYMup/w8CAkOeCBfonArygNMJYPV8tPNQcGeawUAgsVDUYGV2WsTjUrlDU6TX971nqvHR4LVu2jKxdeyFpX7q0aniodX7GsgYUAgvlBTh2oaEv+BleGx8fJ0ePvqrluC66+BLTSKd24SECC4XAQhlJUorNKu4YGqBVRkhtUNQfp6amyGuvHdWKUS+77DISj9uPdhrHpDsKzgPcBagSIFjoZVz01/QxqWIMbtb1IPEes3m+2jqEfe7o2bPkzy++SCYmxh3fj0Khw0KZw0EvDsqn2zJBxxBi6s9DecTrr71GLr30sophmrEvIQqBhbKFiRFaxvDQtD5heSZ43foZVWbJiTmEh7qTeuedt7W7gnBHUVf70qVZPErhKn/91dL1UEFgocoQcYBWVXmYxssOjE7AguXE8WOkta2NtLa24sGJTjw9VEji8ReEX1TQZ6PKsLBAg1jyWk55Ki/5K578FnznAoXgsXfewQODQoeFcnE+LMwzhoMFUu5faHze7m6il47TTu6KWJzW9PQUOXs2T1aswL7zqJCAJWMcjKoCFB1G1sjPAi4jvJzA5CkstIDK6PigbyICCxWmw+rkXB9Ha4iGWJWJdua2rFByclxcULRAq8Jxsb/n5+bI+NiYVhGPQkkXEiYefwFHa4jIYdkl2o13AytCQbsCU05H5wQqI8jGxxFYKEmBhYoOWMZOzG7gsgOPF4dlGw4S+zKH0noasMbxAKEQWKiyykPEGEI2PSy0hIqmTtAewRXjqMUqhaiGz5yamsSDhEJgoeydT6E85ostuHSQ6O/yGhraOSwnUBnLHmZnZvEgoRBYKPuQ0A5cJWfl1knaByCJQwGp8W8ocUChEFioMixsarCMf7sm2z3msEgVh2UHq2IIiZ2fUVjpHpiuu2690sVCxtEa4obqc70C3e7RVOEOf3tZbCrbrZ9t+puYa7VQ6LBQwQjqzbJ1ERISlhTXXZXFYTkN9FftTqFTtXuFwzK4sfLzeIKh0GEFqaTSJ4Kdc4Jx1A2uK27juqyuyG2JOTg3bTE4O6I7NsP6MNCf6rr/gd4uxTYZR2tAYMnvsKzlC8a8ldF5aX/aOCcvXXVi5i+vcFnGbXL7HJVEdwu48AHFogavCqWHCgIL5QiEmE0oaCwetSswJTaTUzjFdF6GmqkGPsWUq+NTKJQeKgis4LRB9ZDQdqA+J2gRh2JRP52fSfX6LNWB9bX7HkzS/ZTDZlLjeYq7IDhdd936TnW3PqYNQ2x3x84tR+Uld+X2Hi/jbBUf1T5VKaw6vXZfQkXrsFKyxcGCY34lfwPMSlNsT1qvQaLPB2h1VU5zDloaJ1co5+6oYnWSvyoofRcZHVaEcbBAbVI5JARoARuKj/GS63Ktv3KbZcdmCBm3kUbLf8cNjq+8TYojawMh6LBUcFiNpJS6m65DRL87WC5eLxRKPQYNACoE4qiM9wutNVdmt6UusO6+5z4oD0jR3dSHTaS+HJbqSlx33fq0qiGh7m4qXVXZ5VjXK7sw74v5PTHD5+rfETe5Ld1pKayuYv9xdFjosOTTFrpklPRYBmdjdVVOjspvG3TOg8Vs3ZbSwWChsMW631DosKQJC6nLUjE0zFvhZXZVTu4o7mtxcmlGt1UPsLrzrnvh7mDKOAoGSm6HxZNI76yT/dpL1LsjNOjVfZWdgx1RCibnVV495viZHpVT9FzYWgYVAksFh8Vzm79epkdR0WVxl2MYpi40LDFLXkpfKtfl1POqnQR33HkPOKu0XiaCBgtDQpm1W6UhZ3b1/3OeyF1DllXvFCj06qBaWFAyJFyHwKoWP15/db2EhUkWGqqkPZJuV44CVamC3NvvuHsb5VNKB5WiOawkx7oH6wJYicdf4L0y1tOsmdsUK3PIEDmLd5WqX6KwgkR7rxlU+oKqt5Awpei+dHKGO1XpY8jCwl0SuquMKifB9tvvSlBA7aZLwgiqBnBYdQUsHpe1jqiphMvzBxTqGN1P5Mpl9ah0ElAo7Sv2GyyDamFhoRGAlasnYDViaYOS0GIuq1uS0LCfbo8yA971bL9zN4VUyuioigspJd5VUf76q3ndVV0Bi+eWdCfdWfWUx1IRWoMSOJss3Q5l3FXP9jsAVmkjqIoJd8L+v0AUy2Hxnqd1Baws5/opUp/SoZVWAFoZ5rSiEABzsyKgStDlANRb2YNK2RwWF7ASj79QV8DizYkoPXqnB2hBjdZO2eu0GLSuDTk8zNDvvZaFplJrW8/tcDfwiLHrTSWoFlQta+Bpg9mwNioUYFH65jkto2qzi/g63+lyRPaKeBYedhDxkyfAObKZfl+3Egev53bt+FEIJXVQlYtDzaDSHZdKOSxOh5ULa6PCLGvgoXCyjgpIXX8nCxHBcSUlhlaeLhCibRRwNQVQQZ1VhwoJdgqqFF0AVDu9gkq1HBZrezzuP7RuU2EOL7OfLmmO9bcQ9YdM9qp0PB5Pv//9qUw8HuvLZg/kZNxIChSAVXbrtu0pdnzSNXwc/EaorO9XJPyDC0pvsW8gIebxrcrDR+sQ0/9vfE0h8UY4oYWEoQ3gwe78jfCc0DSU7FDlCFOHVNMZqQ+70tQEj01Z+vceugw8/fTPpG7MFF5dLHzYwB6drsyDDFLQhSOrSlcbcFQAZyOo7GBUHvPe7bXCxkcefigr+2+mbfUIR0iYp+10Zd0Bi+2IfZz03kx3hhJ1OLUAyziuFAOWcazzAbocpEv2qaeebBTHGal6tt/RyQbdg3M16eaaKkFFiPWuoMFdSQ8sVn/1OsdbBmgbDe2Obtgjju7nBNZWotZMubVdPWLmawgbe6pL32cf+tBH8gAuAgCjLuWnP92PAAsEUHeCm6BOqnAN0cZeLyTLQOIHlXUdxULCtI82HZrCBhbAZzfH+ikgflg1HtGBytsMNHRJ0H9KAPvoR7s0gOkObN++JxBgHrT99rtSDEzXMFAljFAJGlQ2TktmbeFcP1u3wILyBgqgAU6XBUO0dGMzM8fxJYAZHNjHPvaJsgOjjz9+/IcND7A77rxbn7FGy7FBzZQZHgUXUFV73TuoVIAVbZtaCMzxlsGwzUQUk1Ds4QRWmu7Ivnp1WW7uivf9pJjwLgHs+k9+uujACNEA9oMf7B2sf0DdA+FdZ3EeQK3HRNLohpxAVN01+QdVofxm2XffVh9tmdQ1sCCJTgGU4yQ5hJEb6xtYlfkrP/Ai5veYAHbDDZ8tOjC4U0cf937vUeUBdtfdX0uxWZU3MPeUMI4rHzSobEFUEU5Wgkp2VNE2mSL8XeJCzy/HIto5UCW8k/NtG30MBhia/N4ltLs76DSzsgYjQpzyWyZgmfJgVgCWXzPlwL67Z7fUACtPSGoClE09FLFxP7x5qGo5rIIjqErPM1Dpz+3JfCcmMbAOcAIr1LuDUYaEoAzLTfFU0+6mO/Va1s2nLsNBv+/1ku9y+AyTA9uSvrHkwOAu5O7d344UYPfce1/SmH9iOSgXGPkDlfPrtYHKyY3VibuKZDjtSIDFku+7CN+Y50m2fg+pM+nhoB9wGeFVNVys/rwGsBgAjD7ffeMXTA7sP/794UGxgLpfLy/Q808JaxK8GqjcXRGp+rqHWipbSLmBSoGEO2+0k4uqPjLKmZ/7WZKPx2Vto6DbL3No6A80MdMUWb6T8FXWjznMr+X0HqsD++KXvgzuVgMYPD7y8EO+AXbv1x5IMNeUMoZ37hCywsYdVN7Du9pBpW+50zqyQoulZ3j77UY2xn4s4p21g/DPLJOji1ShIeu4/Drv+/zmr5xyWNb8VcwufHR5vzHnRVzqwQxAK4eQ9PGhb33TEWD33d+b1HNPhjyUR7dkBYo4UFW6uABAxZ7bu/exmGSwSrDzlsc0QLvriKr9LYp4n4HL2kL47hjCunDXUKYB3pK8bwi4nMFXKGjrqjg+oxRCFotZyc233FoC2OLFiwaXLl0GULqGjReVdAJQbaCyg02woHICUMFlHdN68jqs3YR/lqpdUZqFSGfNYT/cT06qi7mzuslf8eSjvIZ6Xj7T9nmHsNEDxBjAyM65ubkDo6Nnd05MjKdnZmaS8/PzxG7aK71dWxu7/XqVrzkP52Ie6dM4trr9exdM4DFOHAF/l15neaoFh3VM6xmflwxYLBTkHZUhx0wGaUhgMWhB8s5PTqqX7vS06vkrJ4dlFw7W7Lqcc1U8rspzdgEaLAUXmZ6eIhMTE9oyPT1Nn5utGJ3TDVSVk5FWjuTpNtKn3bhUvkAFz1m207hOaT0DvBYspQ2SwKqT+Jvkty/qVIws8xL6naVlN+tOELUG/cGKL43IEzrGOMPEmA9X5fZ/82sxAxDmyezsrAaumZlpMj8/R4zuqxqo7FwTzwB6FSCyCeUqAGQBldVNFRikCtbnDRCERaK81T4foSB0w8lEvf1SAIt1u/F752F31KOTHj58yNdVR3QdFm8oyJm/qvq6M8DKMjb+YkOvDBHt5/jzByqnnJMtgAzQ8QKq0nOGkHGBvV6QBFhUB4i/CVKlKCeSZuZnCq1+n6GhNhONBE4rzwsbYzmDU5joNRFWFRxewz6bz6qev4q5pb+qfG/MNoUWj8fY3dPiXVOnPJR9nsoZVIUqIV3BwR1VfIYNqBb0xQAqUn5P5He1aRuBJLufi3u/LKVEsk1Vv9lnaKjZ3IhzWtw1ScaQ0DXvRLwXh3p1PNXeww+t6kCqBjM7EMJzTU2LSHNzi7YsXrxYAxms6u64KkFFLG6pAkA2oKoIFfXF+LwVVHZJ94WFQQlg5ad91BL91DewWEKvlnKF3RHePTzoJwwUUc5QpTuO53CQN0QVsb41rFy0qAivJUuWaEtraxt9bjFbzy4Zb06oW5PqJRfkso6NWyol1Bfscl6WMJe9PqggrLT8skw1j7I5LMKsZy3jX8Hdw30RzB7NmXi3ug/5yhl481fG/zrlr7zfkay+LyBcBMfV1tZGli9fTpcVpL19KQVas/aaV1AteASV8c6fFVTWpLvpLmFx/ecVhFW/bL1KZO49XsuO1q0sjAkf2pXtuuvWj5Aqd194q9uNjqna6AwlSBFi/zluo5pa8ld261gf9Txc+f92oDR+hvVz7D7TfGpWfh9xXccIQbj7ODs7o92RLJZTzHkv+iw+aX6eEPv+gw6OTn8P+86VTz75n/kQ2482YS/xP8cn3BW8VjYuxGUFFt1Z4LJq6WCZpMuRkENET9vLU84QI3xV7TFOtxVGOYOb++LPiXkPI5uamjT3lUgkyAUXrCVr164lK1etIkva27WLhGvRp0MtlTWX5ZTrWjA4r/b29sGQYQWJ9QM1wAq2Vcrx5xYRudXNwFNL2QKEiJvoY08I9naPmyt06uzM2xhlL2eoPZcVC+Q7rG+H5H17+2ItbASBA5ucnKTLBJmcmNTcWIVTIpXdctycWcHgzACYV1x5FYSru0KEVRfx1+XGBCtZh3GKSQ4s3doeqBFaujIMXMIOBg0LHQdC08M/PSSMxeK2IaExP+UlHDSBzA5q1Sa4MLRup/WcwrPysDhiw0Hzo7/1XN0g/RsKWiehIn98nIxPjJOZmZkKUNlCygIqHVZXX/1ecHNaZ+HeB+/Lh9BOoHp9W60mQYYCUeVCQkNoqNvTIHJR4H5eZ/2oRKnqLeBq41/ZjS7qxXU5fZnXcgb+8DDm6VoYhBnjyV9xOzv2NyTwl69YQS686CJy+eVXkCuuuIJcfPHFZCUNKRfR16zhozX000NDuAC9pwgr+NhdIcAKLpBH6h1WSjisAJOIFUlFUWGincuqMllq1eFk7JyR3XAybuvYOaiYBWxVhpOpcEleHJST+6r8TGLjzPy5K7d1nYBl1yCM64HjyudH6JIno6Ojtq5rzZo1ZF2yQyu/YOGVMHfFJj3dGVCbkB5WSgHLcJBqvXsoPEykwOpkV7wKYFnvDuq3370Cy/XOX4DhoJ0Lq4RYJbC8hYNOUBIRDgYHLONzkP8CaEH4CAFhS3OLltBnoNLVQ2HVL6ANBBX+KQUrJYHFDpifSSyqJRr7WPegoKC1gxh6xGM5Q+35Ky+OiTt/ZQ15OUNkNwdPYXWtgHMfzivekXrrAlZK5LAc8lr9LK8VlCuCg7+TngxHWD6gZh0+fAhOLN/hptfuOCbwVMvV1JSvqr07jt9yBq93LP1Uzwu6esN5Gejkv9DtjC6vE/7JW+oGVsoCi0ELYNBBgp0qW6tfgbAzoEp56GY0GOboolz9BTkas6tL8QPkAOuuKt8f/GdyCkLBQAqW4QLKpuCCVEgyQKBeqxqslA0JHWxyb9AfG0SYCOO909DvCF0SMAKBNX/lmEwn9VrOEGb+yls5A2/+yk2Tk5N9//iNr+8I4JxOkuAS6qZQlRR7gORUbOt1ASx2gDvZAU4JOMA13U1cv/79nRRO+5qa4skIJkv1lb9yyg9Vz19VwiPM7jjVgOUEq4DyVxnqrLprPI+DTqibto8IrkNEYPmI9Rm4EjId7I0b/2eCnvAHYrF4J8/sOFjOEH05gxdgnT51KvPNb+6qFVbgzLYKOHfzLF81oHr7jtcbsFhcDrmtoG8nAwh9F50eOPDLPIXVRnrSZyKeLNXZYQgeXdT99aC6+oR7vsH49ACDWmAlKKGuCyDVUQ+wqkuHpUKY+Jd/+YE0bbQ7YaJS27wTwXIG4eUMnA7LDrKzs7O5xYsXb/abYGd3pOH8FDHEd46dowP11KbrGliGE2OboKuX7zDxr/7qgwkGrbTkk6W6hnxewkH7151DvSDDQS/5Kz/h4PT0dKalpaXHTxU7S6jvFnAh1cM/6Gzdr3KuqqGBxU6SBLuapQWcIL7vJn7wgx9O0cbQS5eUm7sqNRrO/FXMoSLemr+qVt0eVP7KDUayV7czZYeHh/t29f9TVqJz0HgB7VP1DiACK1wbXlOY+OGPbILt6qUHJBVVd5z6KWcIHliTk5O50dHRvoe+9a8Zn6ACly8ioa5BlJ17g/XefhsOWCGEif2khgknP/rRrrQGrlgsGUU5gyz5K1nKGSYmJnLnzgGovpnxeZ6l2XmWFJSn6pZtGGMElpphYk8tlcRdXR+D3JZ2ovvJX7lCq4b8VaOUM2igAkf1kG9QiXLygZxfCCwME4VY9Y997BM7aCMqhhIO+Su3HFcQ+Ss/ozN4z1/JFQ7Ozc3lhoeGagEVOClMqCOwGjdM/PjHrwdYbdPB5Zi/qhYKKlbO4AQ1L2DzASwIr/r6djzgF1SYUEdgYZho1Ceu/1SpFII3f4XlDI75qyBAhQl1BBaGiU765KduSMaKifm0qbH7CAfrIX/lMxzMxWoAFTtH0kRMNzCQsBFxEVgYJoYeJoI+/enPQEJ+t1bDZZOXEjG6qOrlDLNzc/nZ2dm+//2/vtFfwzmRIsEO92JUjp0XGWx9CKy6CxNBn/nM56DoFKCaarTJUr2GgxRS+bGxsV2/++1v+g8fPpT3eR6I6uqlnwsNnVBHYDVQmAj67Oc+D8DStk+VcgbR+as56qgCAFWSuey0oFMrQxQf9gWBhWGib/3159PQsMzFpzb5q1rKGXiAFUU4OEcd1TkKqt//7re1gCqMhHp3o9/5Q2BhmKhpS/pG2LbiqBAO+auwu+OInix1bg5Cv/GaQMWOb5pgQh2BhWFiuGFiuvtvNJcQA5fAhrNxgpZTOOjsoLyXM4jOX2mh3znqqH7/u1pBBccTE+oILAwTowwTu2/8QhFcsdhWcFwy5K+C6I4zPw+gOkdB9ftaQYUJdQQWhomyhYk3/s0Xk2w4m7Tf/JUM5QzFZPq5XUdqB1WSYEIdgYVhorxhIugLX7wpyTpXp1UaXZSCiiwsLPS3tLT0/f3X+2oBlZ5Q7xV0GgywY5XDFoHAwjAxgDAR9KWbbi6FQjJ3x4Gp4ScnJzNDQ2f69n7v0Zykx0W/qPRhQh2BhWGioDARdNOXbwFXqI18KracgS9/pYNqeHgoCFB1sWORFHCocwQT6ggsDBPDCxNBX775KwAsdpcsuu44c3PzZGqKgmpouG/v3ppBlWKOKiXi0NJlF93/O/AsR2BhmBhBmAi6+ZZb06RUfGoFlrjJUiFHNTU5lRmijur7ex+rFVRJIjahHug+RyGwZA4TwcUEPQ154CNR3vKV29IUJFAK0ckTDtrByC0chLt+k5MTmZGRkV0BgAoT6ggslKAwUUSRYqBhIuirt26F/olbipAtdvkxgshPd5yZ6WmYAXtgdHR0/7e//UgmoH2KCXUEFkowuCD/IaK/mpCQ5dbbepJsSJtrKHs6mftKVAsH52bnBguE5AqFheenpqazjzz8rWyA+xAT6ggsVIjQSrIGJyJM7A5jBuCe7XckwX0ZHRd1T+TfH3koK3C/pQgm1BFYqLoME+tmZACBgNfVR7ArDQILFXmYqHRDZAl1cFTbBH1FhuBkDwgslFQuIkcUzMkIhLjuQDGhjsBCSRwmKgGuEGZP7gkjx4dCYGGYGCC46DIgS6hoqKXaIghUeQbrfjyzEFgo9cJEvRGD09gV1Tx4rDxhExFXnU4IJtQRWKi6CRONrgvgtV9kXoc5qRSDVBcRk5/SlSGYUEdgoeoyTLQKoHWQFMcjz/l1YGxkT1iuYaDqDGE3ZQkm1BFYqIYIE6u5MN2tAMDOWl5fZ3CAnSFA1W77MKGOwEI1aJiozK4gAXcCRyGwUOqHiTKCCid7QGChMEyUXuCmMKGOwELVQZgoYqRTWZQlAQ+lg0JgoaIHV5qIqxaPClR45w+BhWoAcEH1eApBhUJgoVQBF4SIkJgXXawZyOaSYo5qF+aoEFioxgZXgkFLrzSXSVA/tQfrqFAILJQbvDawkDEZ8ibkWMi3HyGFQmCheAGWZOCCbjSdJNi8F4R5g2zRuvxguIdCYKFEuLBO5r50B7aCOJdNGLvsDOqgwsJOFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQcuv/CzAA632bpNH5E2YAAAAASUVORK5CYII="
            onClick={() => navigate.to("/")}
          />
          <Typography className="th-text-neutral-50 font-bold" type="h2">
            {props.appName}
          </Typography>
        </Box>
      </Box>
      <Box className="flex lg:hidden">
        <Avatar src={props.userData?.image ?? "تصویر یافت نشد"} />
      </Box>
      <TabBar data={tabBarData} />
      <Box
        className="relative cursor-pointer select-none"
        onClick={() => setIsProfilePopover(!isProfilePopover)}
        handleClickOutside={() => setIsProfilePopover(false)}
      >
        <UserProfile
          viewMode="navbar"
          userImage={props.userData?.image ?? "تصویر یافت نشد"}
          partnerName={props.userData?.partnerName ?? ""}
          fullName={props.userData?.fullName ?? "نام کاربر یافت نشد"}
          onClick={() => {
            setIsProfilePopover(true);
            setShowSetting(false);
          }}
        />
        {isProfilePopover && (
          <PopoverMenu
            dataRenders={popoverProfileData}
            position="right"
            useInNavbar
          />
        )}
      </Box>
    </Box>
  );
};
