//@ts-ignore
import NumberToPersianWord from "number_to_persian_word";

export const ConvertNumToWord = (num: number) => {
  return NumberToPersianWord.convert(num);
};
