import React from 'react'
import PagesCard from './services/components/PagesCard'

export default function Rules() {
  return (
    <div>Rules</div>
  )
}
