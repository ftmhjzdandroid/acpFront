import React from "react";
import { useLocation, useParams } from "react-router-dom";

export const AssignmenLaw = () => {
  const param = useParams();
  console.log(param,"***");

  return (
    <>
      <h1>jnjknjkn</h1>
    </>
  );
};
