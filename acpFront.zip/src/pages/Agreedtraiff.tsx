import React from "react";
import PagesCard from "./services/components/PagesCard";

export default function Agreedtraiff() {
  return <div>Agreedtraiff</div>;
}
