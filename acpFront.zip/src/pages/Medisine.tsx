import React from 'react'
import PagesCard from './services/components/PagesCard'

export default function Medisine() {
  return (
    <div>Medisine</div>
  )
}
