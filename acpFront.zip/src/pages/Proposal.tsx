import React from 'react'
import PagesCard from './services/components/PagesCard'

export default function Proposal() {
  return (
    <div>Proposal</div>
  )
}
