import React from 'react'
import PagesCard from './services/components/PagesCard'

export default function Setting() {
  return (
    <div>Setting</div>
  )
}
