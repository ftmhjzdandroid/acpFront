import React from 'react'
import PagesCard from './services/components/PagesCard'

export default function Feature() {
  return (
    <div>Feature</div>
  )
}
