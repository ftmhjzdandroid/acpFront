import React from 'react'

export default function Classification() {
  return (
    <div>Classification</div>
  )
}
