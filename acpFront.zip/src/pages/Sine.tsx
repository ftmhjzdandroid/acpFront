import React from 'react'
import PagesCard from './services/components/PagesCard'

export default function Sine() {
  return (
    <div>Sine</div>
  )
}
