import React from 'react'
import PagesCard from './services/components/PagesCard'

export default function Type() {
  return (
    <div>Type</div>
  )
}
