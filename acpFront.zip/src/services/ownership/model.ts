export interface IOwnershipModel {
  name: string;
  itemId: string;
}
