export interface InitializeModel {
  name?: string;
  fullName?: string;
  ssoUrl?: string;
  sso?: string;
  appVersion?: string;
  env?: string;
  currentTime?: string;
}
